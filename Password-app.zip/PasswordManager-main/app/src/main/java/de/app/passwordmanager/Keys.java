package de.app.passwordmanager;

public class Keys {

    public static final String KEY_OLD = "old";
    public static final String KEY_NEW = "new";
}
