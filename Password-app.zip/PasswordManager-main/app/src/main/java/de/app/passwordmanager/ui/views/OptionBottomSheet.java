package de.app.passwordmanager.ui.views;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import de.app.passwordmanager.R;
import de.app.passwordmanager.databinding.MoreBottomSheetContentBinding;
import de.app.passwordmanager.dialog.DeleteDialog;
import de.app.passwordmanager.manager.ActivityResultManager;
import de.app.passwordmanager.security.element.SecureElement;
import de.app.passwordmanager.ui.dashboard.DashboardFragment;

public class OptionBottomSheet extends BottomSheetDialog {

    private final SecureElement element;

    public OptionBottomSheet(Context context, SecureElement element) {
        super(context);
        this.element = element;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MoreBottomSheetContentBinding binding = MoreBottomSheetContentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.title.setText(element == null ? getContext().getString(R.string.options) : element.getTitle());

        binding.edit.setOnClickListener(v -> {
            ActivityResultManager.getOrCreateManager(DashboardFragment.class, null).launchEdit(element, getContext());
            dismiss();
        });

        if(element == null)
            binding.edit.setVisibility(View.GONE);

        binding.delete.setOnClickListener(v -> {
            new DeleteDialog(getContext()).show(null, element);
            dismiss();
        });

    }
}
