package de.app.passwordmanager.dashboard;

public interface Item {

    long getId();
}
