package de.app.passwordmanager.dashboard.viewholders;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import de.app.passwordmanager.dashboard.selection.SecureElementDetailsLookup;
import de.app.passwordmanager.security.element.SecureElement;

public abstract class BasicViewHolder<T> extends RecyclerView.ViewHolder implements SecureElementDetailsLookup.ItemDetailsLookup {

    public BasicViewHolder(@NonNull View itemView) {
        super(itemView);
    }

    public abstract void bind(@NonNull T item, String filter, OnItemClickedListener onItemClickedListener);

    public abstract void onBindSelectablePayload(boolean selectable, boolean selected);

    public interface OnItemClickedListener {
        void onClicked(SecureElement element);
    }
}