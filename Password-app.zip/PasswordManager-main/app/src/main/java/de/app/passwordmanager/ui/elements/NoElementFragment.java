package de.app.passwordmanager.ui.elements;

import androidx.fragment.app.Fragment;

import de.app.passwordmanager.R;

public class NoElementFragment extends Fragment {

    public NoElementFragment() {
        super(R.layout.fragment_no_item_selected);
    }
}
