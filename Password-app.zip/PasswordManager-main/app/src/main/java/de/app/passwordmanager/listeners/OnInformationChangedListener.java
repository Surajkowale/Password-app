package de.app.passwordmanager.listeners;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import de.app.passwordmanager.dialog.EditDialog;
import de.app.passwordmanager.security.element.ElementDetail;
import de.app.passwordmanager.security.element.SecureElement;
import de.app.passwordmanager.security.element.SecureElementManager;

public class OnInformationChangedListener<E extends SecureElement> implements EditDialog.OnInformationChangeListener {

    private final E element;
    private final ApplyChangeToElementHelper<E> helper;

    public OnInformationChangedListener(@NonNull E element, @NonNull ApplyChangeToElementHelper<E> helper) {
        this.element = element;
        this.helper = helper;
    }

    @Override
    public void onInformationChanged(EditDialog dialog, String information) {
        ElementDetail detail = helper.applyChanges(element, information);
        if(detail != null)
            element.setDetail(detail);

        SecureElementManager.getInstance().editElement(element);
    }

    public interface ApplyChangeToElementHelper<E> {
        @Nullable
        ElementDetail applyChanges(E element, String changes);
    }
}
