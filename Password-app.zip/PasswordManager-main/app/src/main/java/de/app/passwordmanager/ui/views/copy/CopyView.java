package de.app.passwordmanager.ui.views.copy;

public interface CopyView  {

    String getCopyString();
    void setCopyable(boolean copyable);
}
